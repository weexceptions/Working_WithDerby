/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pro.controller;
import com.pro.dao.DBconnection;
import com.pro.dao.UserDAO;
import com.pro.dao.DaoImpl;
/**
 *
 * @author Sunny
 */
public class TestMain  {
//    public static void main(String[] args) {
//        
//    UserDAO userdao = new DaoImpl();
//    }    
}
